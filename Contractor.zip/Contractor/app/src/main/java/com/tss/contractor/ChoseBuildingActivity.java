package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class ChoseBuildingActivity extends AppCompatActivity {
     RadioButton chose, skip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_building);
        chose = findViewById(R.id.chose_id);
        skip = findViewById(R.id.skip);
        chose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChoseBuildingActivity.this, ToolsActivity.class);
                startActivity(intent);
            }
        });
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChoseBuildingActivity.this, ChosiceStrcutre.class);
                startActivity(intent);
            }
        });
    }
}