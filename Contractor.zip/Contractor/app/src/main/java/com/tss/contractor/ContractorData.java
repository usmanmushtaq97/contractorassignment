package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tss.contractor.DataBaseHelper.ContractorDataModel;
import com.tss.contractor.DataBaseHelper.ContractorModel;
import com.tss.contractor.DataBaseHelper.DataBaseContract;

import java.util.List;

public class ContractorData extends AppCompatActivity {
    Button savebt;
    EditText text_of_information;
    String contractData;
    DataBaseContract dataBaseContract;
    List< ContractorDataModel > modelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contractor_data);
        dataBaseContract = DataBaseContract.getInstance(this);
        text_of_information = findViewById(R.id.contractorinfodataET);
        savebt = findViewById(R.id.btsavecontract);
        savebt.setOnClickListener(v -> {
            contractData = text_of_information.getText().toString();
            if (!contractData.isEmpty()) {
                dataBaseContract.daoCarts().InsertContractorData(new ContractorDataModel(contractData));
                Toast.makeText(this, "Inserted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ContractorData.this, ContractorEdit.class);
                intent.putExtra("info",contractData);
                startActivity(intent);

            } else {
                Toast.makeText(this, "Enter Data Before", Toast.LENGTH_SHORT).show();
                  }
        });
    }
}