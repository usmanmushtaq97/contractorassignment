package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ContractorEdit extends AppCompatActivity {
   Button editnext;
   EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contractor_edit);
        editnext = findViewById(R.id.editnextbt);
        editText  = findViewById(R.id.editinfo);
        Intent intent = getIntent();
        String info = intent.getStringExtra("info");
        editText.setText(info);
        editnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContractorEdit.this, ExitContractor.class);
                startActivity(intent);
            }
        });
    }
}