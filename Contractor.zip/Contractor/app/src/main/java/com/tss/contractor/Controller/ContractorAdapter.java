package com.tss.contractor.Controller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tss.contractor.DataBaseHelper.ContractorDataModel;
import com.tss.contractor.R;

import java.util.List;

public class ContractorAdapter
        extends RecyclerView.Adapter< ContractorAdapter.ViewHolder > {

    private Context mContext;
    private List< ContractorDataModel> mFoodItems;

    public ContractorAdapter(Context context, List<ContractorDataModel> workerItems) {
        this.mContext = context;
        this.mFoodItems = workerItems;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.contractitems, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
      ContractorDataModel workerItems = mFoodItems.get(position);
        holder.mListTitle.setText(workerItems.getInformation());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  Intent intent = new Intent(mContext, MapsDetails.class);
                //mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mFoodItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mListTitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mListTitle = itemView.findViewById(R.id.info);
            // mDescription = itemView.findViewById(R.id.w_sub_title_id);

        }
    }

}
