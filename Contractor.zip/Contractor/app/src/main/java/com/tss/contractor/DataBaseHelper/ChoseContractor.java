package com.tss.contractor.DataBaseHelper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import com.tss.contractor.ListOfContractor;
import com.tss.contractor.R;

public class ChoseContractor extends AppCompatActivity {
    RadioButton chosebutton;
    RadioButton skipeRadio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chose_contractor);
        chosebutton  = findViewById(R.id.chose_id);
        skipeRadio  = findViewById(R.id.skip);
        chosebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChoseContractor.this, ListOfContractor.class);
                startActivity(intent);
            }
        });
        skipeRadio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ChoseContractor.this, ListOfContractor.class);
                startActivity(intent);
            }
        });
    }
}