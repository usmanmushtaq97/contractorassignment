package com.tss.contractor.DataBaseHelper;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
@Entity (tableName = "contractorlist")
public class ContractorDataModel implements Serializable {
    //primary key auto increament
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "contractor_data_id")
    private int cid;
    // product id which get from server
    @ColumnInfo(name = "information")
    private String information;
    public ContractorDataModel(String information) {
        this.information = information;
    }
    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getInformation() {
        return information;
    }

    public void setInformation(String information) {
        this.information = information;
    }
}

