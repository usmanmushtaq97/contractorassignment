package com.tss.contractor.DataBaseHelper;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;

@Entity (tableName = "contractoruser")
public class ContractorModel implements Serializable {
    //primary key auto increament
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "contractor_id")
    private int cid;
    // product id which get from server
    @ColumnInfo(name = "name")
    private String namecontractor;
    @ColumnInfo(name = "email")
    private String con_email;
    @ColumnInfo(name ="con_number")
    private String con_number;
    @ColumnInfo(name = "password")
    private String password;
    @ColumnInfo( name ="address")
    private String address;

    public ContractorModel(String namecontractor, String con_email, String con_number, String password, String address) {
        this.namecontractor = namecontractor;
        this.con_email = con_email;
        this.con_number = con_number;
        this.password = password;
        this.address = address;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getNamecontractor() {
        return namecontractor;
    }

    public void setNamecontractor(String namecontractor) {
        this.namecontractor = namecontractor;
    }

    public String getCon_email() {
        return con_email;
    }

    public void setCon_email(String con_email) {
        this.con_email = con_email;
    }

    public String getCon_number() {
        return con_number;
    }

    public void setCon_number(String con_number) {
        this.con_number = con_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}