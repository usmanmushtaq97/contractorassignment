package com.tss.contractor.DataBaseHelper;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface DaoContractor {
    //insert the carts item
    @Insert
    void InsertCarts(ContractorModel contractorModel);
    /// get all data from query
    @Query("SELECT * FROM contractoruser ")
    List<ContractorModel> getAll();
    @Insert
    void InsertContractorData(ContractorDataModel contractorModel);
    @Query("SELECT * FROM contractorlist")
   List<ContractorDataModel> getAllCont();
    
}
