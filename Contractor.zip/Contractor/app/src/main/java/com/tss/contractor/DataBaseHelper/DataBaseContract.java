package com.tss.contractor.DataBaseHelper;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
@Database(entities = { ContractorModel.class, ContractorDataModel.class},version = 1,exportSchema = true)

public abstract class DataBaseContract extends RoomDatabase{
    //data base instance
  public static DataBaseContract instance;
    private static String databasename="db_contractor";
    public synchronized static DataBaseContract getInstance(Context mcontext){
        // check
        if(instance == null){
            instance = Room.databaseBuilder(mcontext, DataBaseContract.class,databasename).allowMainThreadQueries().fallbackToDestructiveMigration().build();
        }
     return instance;
    }
public abstract DaoContractor daoCarts();
}
