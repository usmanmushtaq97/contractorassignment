package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ExitContractor extends AppCompatActivity {
    Button evaluationappbt;
    Button exitbt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit_contractor);
        evaluationappbt = findViewById(R.id.btgoevalution);
        exitbt = findViewById(R.id.editnextbt);
        evaluationappbt.setOnClickListener(v -> {
            Intent intent = new Intent(ExitContractor.this, ContractorApplicationEvalution.class);
            startActivity(intent);
        });
        exitbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
            }
        });
    }
}