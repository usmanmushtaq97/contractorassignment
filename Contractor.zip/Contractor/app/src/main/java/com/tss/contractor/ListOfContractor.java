package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.tss.contractor.Controller.ContractorAdapter;
import com.tss.contractor.DataBaseHelper.ChoseContractor;
import com.tss.contractor.DataBaseHelper.ContractorDataModel;
import com.tss.contractor.DataBaseHelper.DataBaseContract;

import java.util.ArrayList;
import java.util.List;

public class ListOfContractor extends AppCompatActivity {
   RecyclerView recyclerView;
   List< ContractorDataModel> modelList;
    DataBaseContract dataBaseContract;
    ContractorAdapter adapter;
    Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_contractor);
        recyclerView = findViewById(R.id.rvcontractor);
        bt = findViewById(R.id.btnextcontractor);
        modelList = new ArrayList<>();
        dataBaseContract = DataBaseContract.getInstance(this);
        modelList = dataBaseContract.daoCarts().getAllCont();
        adapter = new ContractorAdapter(this, modelList);
        LinearLayoutManager layoutManager1 = new
                LinearLayoutManager(this);
        layoutManager1.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager1);
        recyclerView.setAdapter(adapter);
        //adapter.notifyDataSetChanged();
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListOfContractor.this, ChoseBuildingActivity.class);
                startActivity(intent);
            }
        });


    }
}