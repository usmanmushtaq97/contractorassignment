package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tss.contractor.DataBaseHelper.ChoseContractor;
import com.tss.contractor.DataBaseHelper.ContractorModel;
import com.tss.contractor.DataBaseHelper.DataBaseContract;

import java.util.ArrayList;
import java.util.List;

public class LoginCostumer extends AppCompatActivity {
    Button btloginNext;
    EditText etName, etPassword;
    String password, name;
    DataBaseContract dataBaseContract;
    List< ContractorModel > modelList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etPassword);
        btloginNext = findViewById(R.id.loginnextbtid);
        dataBaseContract = DataBaseContract.getInstance(this);

        btloginNext.setOnClickListener(v -> {
            if (IsNotEmpty()) {
                CheckLogin();
            }

        });
    }
    private Boolean IsNotEmpty() {
        name = etName.getText().toString();
        password = etPassword.getText().toString();
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter The Name", Toast.LENGTH_SHORT).show();
            return false;
        } else if (password.isEmpty()) {
            Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    //***************************************************//
    private void CheckLogin() {
        modelList = new ArrayList<>();
        modelList = dataBaseContract.daoCarts().getAll();
        for (ContractorModel contractorModel : modelList) {
            String email = contractorModel.getCon_email();
            String pas = contractorModel.getPassword();
            if (email.equals(name) && pas.equals(password)) {
                Intent intent = new Intent(LoginCostumer.this,ListOfContractor.class);
                startActivity(intent);

            } else {
                Toast.makeText(this, "enter correct password", Toast.LENGTH_SHORT).show();
            }
        }
    }
}