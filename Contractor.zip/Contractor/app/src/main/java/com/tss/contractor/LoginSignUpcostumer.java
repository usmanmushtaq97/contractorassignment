package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginSignUpcostumer extends AppCompatActivity {
   Button login, signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_sign_upcostumer);
        login = findViewById(R.id.loginbtC_id);
        signUp = findViewById(R.id.register_id);
        login.setOnClickListener(v -> {
            Intent intent = new Intent(LoginSignUpcostumer.this,LoginCostumer.class);
            startActivity(intent);
        });
        signUp.setOnClickListener(v -> {
            Intent intent = new Intent(LoginSignUpcostumer.this,SignUpCostumer.class);
            startActivity(intent);
        });
    }
}