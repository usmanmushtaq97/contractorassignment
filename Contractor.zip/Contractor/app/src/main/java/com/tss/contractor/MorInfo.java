package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MorInfo extends AppCompatActivity {
  Button btcontractor, btCostumer;
  TextView  tvVisitmore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mor_info);
        btcontractor = findViewById(R.id.btcontractorid);
        btCostumer = findViewById(R.id.costumer_id);
        tvVisitmore = findViewById(R.id.vistitmoretvid);
        btcontractor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MorInfo.this, LoginSignUpCon.class);
                startActivity(intent);
            }
        });
        btCostumer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MorInfo.this, LoginSignUpcostumer.class);
                startActivity(intent);
            }
        });
        tvVisitmore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( MorInfo.this, VisitMoreInfo.class);
                startActivity(intent);
            }
        });
    }
}