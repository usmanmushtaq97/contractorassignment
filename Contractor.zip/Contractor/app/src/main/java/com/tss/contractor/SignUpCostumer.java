package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tss.contractor.DataBaseHelper.ContractorModel;
import com.tss.contractor.DataBaseHelper.DataBaseContract;

public class SignUpCostumer extends AppCompatActivity {
    Button mNext;
    EditText mFirstNameET;
    EditText mAdress;
    EditText mPasswordEt;
    EditText mEmailEt, mMobileNumber;
    String name;
    String email;
    String adress;
    String password, mobile;
    DataBaseContract dataBaseContract;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        dataBaseContract = DataBaseContract.getInstance(this);
        init();
        mNext.setOnClickListener(v -> {
            if (IsNotEmpty()) {
                dataBaseContract.daoCarts().InsertCarts(new ContractorModel(name, email, mobile, password, adress));
                Intent intent = new Intent(SignUpCostumer.this, LoginCostumer.class);
                Toast.makeText(SignUpCostumer.this, " Congratulation you are Register", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                Toast.makeText(this, "c", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void init() {
        mNext = findViewById(R.id.signup_bt_next);
        mFirstNameET = findViewById(R.id.sign_up_name);
        mAdress = findViewById(R.id.signup_adress);
        mEmailEt = findViewById(R.id.signup_email_id);
        mMobileNumber = findViewById(R.id.signupphone_id);
        mPasswordEt = findViewById(R.id.signuppassword);
    }
    private Boolean IsNotEmpty() {
        name = mFirstNameET.getText().toString();
        adress = mAdress.getText().toString();
        email = mEmailEt.getText().toString();
        mobile = mMobileNumber.getText().toString();
        password = mPasswordEt.getText().toString();
        if (name.isEmpty()) {
            Toast.makeText(this, "Enter The Name", Toast.LENGTH_SHORT).show();
            return false;
        } else if (adress.isEmpty()) {
            Toast.makeText(this, "Enter Address", Toast.LENGTH_SHORT).show();
            return false;
        } else if (email.isEmpty()) {
            Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show();
            return false;
        } else if (password.isEmpty()) {
            Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mobile.isEmpty()) {
            Toast.makeText(this, "mobile number", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}