package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Sucessfully extends AppCompatActivity {
    Button evaluationappbt;
    Button exitbt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sucessfully);
        evaluationappbt = findViewById(R.id.ev);
        exitbt = findViewById(R.id.ex);
        evaluationappbt.setOnClickListener(v -> {
            Intent intent = new Intent(Sucessfully.this, ContractorApplicationEvalution.class);
            startActivity(intent);
        });
        exitbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
            }
        });
    }
}