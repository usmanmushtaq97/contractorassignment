package com.tss.contractor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class ToolsActivity extends AppCompatActivity {
    Button bt;
    Spinner sand, iron, wood, buildingbricks;
    String[] sand_array = {"Maxican  per ton  20R", "Indian per ton 150R"};
    String[] iron_array = {"Chinese Iron per meter 1300R", "Italian Iron per meter 1300R"};
    String[] wood_array = {"Romanian Wood per meter 1500R", "German wood per meter 6 R"};
    String[] wbricks_array = {"Italian brick per ton 500R", " Italian brick  per ton 6 R"};
    ArrayAdapter adapteriron, adaptersan, adapterwood, adapterbrick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tools);
        bt = findViewById(R.id.activity_tools_id);
        iron = findViewById(R.id.spinneriron);
        sand = findViewById(R.id.spinnersnad);
        wood = findViewById(R.id.spinnerwood);
        buildingbricks = findViewById(R.id.spinnerbrick);
        adapteriron = new ArrayAdapter(this, android.R.layout.simple_spinner_item, iron_array);
        adapteriron.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        iron.setAdapter(adapteriron);
        //sand
        adaptersan= new ArrayAdapter(this, android.R.layout.simple_spinner_item, sand_array);
        adaptersan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sand.setAdapter(adaptersan);
        //wood
        adapterwood = new ArrayAdapter(this, android.R.layout.simple_spinner_item, wood_array);
        adapterwood.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        wood.setAdapter(adapteriron);
        //sand
        adapterbrick= new ArrayAdapter(this, android.R.layout.simple_spinner_item, wbricks_array);
        adapterbrick.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        buildingbricks.setAdapter(adapterbrick);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ToolsActivity.this, ChosiceStrcutre.class);
                startActivity(intent);
            }
        });
    }
}